function setup() {
  createCanvas(windowWidth, windowHeight);
  background(100);
}

function draw(){
  clear();
}

function windowResized(){
  resizeCanvas(windowWidth, windowHeight);
}