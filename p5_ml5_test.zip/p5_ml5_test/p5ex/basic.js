function preload() {
      
}

function setup() {
  createCanvas(600, 400);
  background(100);
}

function draw(){

}